**Arguments:**
* _source: (s:)_ - source file path
* _transform: (t:)_ - transform file path
* _destination: (d:)_ - destination file path
* _parameters: (p:)_ - (Optional parameter) string of parameters used expected by source file separated by ';', value should be separated from name by ':', if value contains spaces - quote it
* _fpt_  - (Optional parameter) force parameters task (if parameters argument is empty, but need to apply default values), default is false
* _v_ - (Optional parameter) verbose output. 

## Example 1 (Without parameters):

source.config file content:
{code:xml}
<?xml version="1.0"?>

<configuration>

	<custom>
		<groups>
			<group name="TestGroup1">
				<values>
					<value key="Test1" value="True" />
					<value key="Test2" value="600" />
				</values>
			</group>

			<group name="TestGroup2">
				<values>
					<value key="Test3" value="True" />
				</values>
			</group>

		</groups>
	</custom>
	
</configuration>
{code:xml}

transform.config file content:
{code:xml}
<?xml version="1.0"?>
<configuration xmlns:xdt="http://schemas.microsoft.com/XML-Document-Transform">
	
	<custom>
		<groups>
			<group name="TestGroup1">
				<values>
					<value key="Test2" value="601" xdt:Transform="Replace"  xdt:Locator="Match(key)" />
				</values>
			</group>
		</groups>
	</custom>
	
</configuration>
{code:xml}

Then you can use one of the command line
_ctt.exe source:"source.config" transform:"transform.config" destination:"destination.config"_
_ctt.exe s:source.config t:transform.config d:destination.config_

destination.config file will have content:
{code:xml}
<?xml version="1.0"?>

<configuration>

	<custom>
		<groups>
			<group name="TestGroup1">
				<values>
					<value key="Test1" value="True" />
					<value key="Test2" value="601" />
				</values>
			</group>

			<group name="TestGroup2">
				<values>
					<value key="Test3" value="True" />
				</values>
			</group>

		</groups>
	</custom>
	
</configuration>
{code:xml}

## Example 2 (With parameters):

source.config file content:
{code:xml}
<?xml version="1.0"?>

<configuration>

	<custom>
		<groups>
			<group name="TestGroup1">
				<values>
					<value key="Test1" value="False" />
					<value key="Test2" value="600" />
				</values>
			</group>

			<group name="TestGroup2">
				<values>
					<value key="Test3" value="C:\Test\" />
				</values>
			</group>

		</groups>
	</custom>
	
</configuration>
{code:xml}

transform.config file content (two parameters there: _Parameter1_ with default value and _Test3Value_):
{code:xml}
<?xml version="1.0"?>
<configuration xmlns:xdt="http://schemas.microsoft.com/XML-Document-Transform">
	
	<custom>
		<groups>
			<group name="TestGroup1">
				<values>
					<value key="Test2" value="601" xdt:Transform="Replace"  xdt:Locator="Match(key)" />
					<value key="Test1" value="{Parameter1:True5665}" xdt:Transform="Replace"  xdt:Locator="Match(key)" />
				</values>
			</group>
			
			<group name="TestGroup2">
				<values>
					<value key="Test3" value="{Test3Value}" xdt:Transform="Replace"  xdt:Locator="Match(key)" />
				</values>
			</group>
		</groups>
	</custom>
	
</configuration>
{code:xml}

Command line with parameters:
_ctt.exe s:s.config t:t.config d:d.config p:Parameter1:True;Test3Value:"c:\Program Files\Test""_

after execution destination.config file will have content:
{code:xml}
<?xml version="1.0"?>
<configuration>
  <custom>
    <groups>
      <group name="TestGroup1">
        <values>
          <value key="Test1" value="True" />
          <value key="Test2" value="601" />
        </values>
      </group>
      <group name="TestGroup2">
        <values>
          <value key="Test3" value="c:\Program Files\Test" />
        </values>
      </group>
    </groups>
  </custom>
</configuration>
{code:xml}

## Links

* [Config Transformation Tool: Using XDT Transformation](http://outcoldman.ru/en/blog/show/223)
* To get more details about transform file syntax go to [http://msdn.microsoft.com/en-us/library/dd465326.aspx](http://msdn.microsoft.com/en-us/library/dd465326.aspx)